 * edit page
 * show difficulty select
 * conditional buttons
 * conditional navigation
 * logout
 * route guards
 * unique users on register
 