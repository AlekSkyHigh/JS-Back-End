exports.isAgeValid = (age) => {
    return age && age >= 0 && age <= 120;
}